How to run crawler:

In order to run the crawler, you have to download twitter4j jar from twitter4j.org.
and put "twitter4j-core-\<version_nr\>-javadoc.jar" und twitter4j-core-\<version_nr\>.jar" in the twitter_crawler folder (I used version_nr = 4.0.4).
